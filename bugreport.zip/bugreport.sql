SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `bugreport`
-- ----------------------------
DROP TABLE IF EXISTS `bugreport`;
CREATE TABLE `bugreport` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `bug` varchar(1000) NOT NULL DEFAULT '',
  `remetent` varchar(1000) NOT NULL DEFAULT '',
  `data` varchar(1000) NOT NULL DEFAULT '',
  `status` int(4) NOT NULL,
  `priority` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=499 DEFAULT CHARSET=latin1;

